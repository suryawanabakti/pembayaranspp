<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2FE9epBr6kpih2a8nb9vKsmWyXO2PKEEK8A&s" alt=""
    width="40">
<?php /**PATH C:\laragon\www\pembayaranspp\resources\views/components/application-logo.blade.php ENDPATH**/ ?>