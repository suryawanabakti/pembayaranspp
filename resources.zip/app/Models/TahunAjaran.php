<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TahunAjaran extends Model
{
    public $table = 'tahun_ajaran';
    protected $guarded = ['id'];
}
